var app = angular.module("app",[]);
app.controller("test",["$scope","$rootScope","$http",function($scope,$rootScope,$http){
		$scope.data = [];
		$scope.formData = {};
		$scope.getData = function(){

			$http.get("http://localhost/traning/api.php?type=fetch")
			.then(function(response){
				$scope.data = response.data;
				console.log(response.data);
			})
			// $scope.data = [
			// 	{
			// 		name : "xxxx",
			// 		age : 22
			// 	},
			// 	{
			// 		name : "zzzzz",
			// 		age : 23
			// 	}
			// ];
		}

		$scope.getData();
		$scope.button="add";

		$scope.addData = function(){
			$http.get("http://localhost/traning/api.php?type=add&name="+$scope.formData.name+"&age="+$scope.formData.age)
			.then(function(response){
				alert(response.data);
				$scope.getData();
				$scope.formData = {};
			})
		}

		$scope.editData = function(clickValue){

			$scope.formData = clickValue;
			
			$scope.button="edit";
		}


		$scope.deleteData = function(clickValue){
			var check = confirm("Do you want delete ?");
			if(check){
				$http.get("http://localhost/traning/api.php?type=delete&id="+clickValue.id)
				.then(function(response){
					alert(response.data);
					$scope.getData();
				})
			}
		}

		$scope.editAction = function(){
			

			$http.get("http://localhost/traning/api.php?type=edit&name="+$scope.formData.name+"&age="+$scope.formData.age+"&id="+$scope.formData.id)
			.then(function(response){
				alert(response.data);
				$scope.getData();
				$scope.formData = {};
				$scope.button="add";
			})
		}
}]);