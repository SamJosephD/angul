var app = angular.module("app",[]);
app.controller("test",["$scope","$rootScope",function($scope,$rootScope){
	

	/*$scope.name = "test";
	$scope.emitName = "before"
	$scope.$on("myEmit",function(event,args){
		$scope.emitName = args.data;
	});*/
	// angular.element(document.getElementById("data")).addClass("red").text("mY datda");
}]);

app.controller("test1",["$scope","$rootScope",function($scope,$rootScope){
	/*$scope.name1 = "test1";

	$scope.emit = function(){
		$scope.$emit("myEmit",{data : $scope.name1})
		// $scope.$broadcast("myEmit",{data : $scope.name1})
	}*/

	// angular.element(document.getElementById("data")).addClass("red").text("mY datda");
}]);
/*
app.directive("myDirectiveHello",function(){
	return {
		templateUrl : "tets.html",
		restrict : "AECM",
		replace: true,
		scope : {
			cname : "="
		}
	}
});

app.component("myComponent",{
	template : "<h1>My component {{$n.cname}}</h1>",
	bindings: {
    	cname: '='
  	},
  	controller : function($scope){
  		this.firstname = "bala"
  	},
  	controllerAs : "$n"
})
*/


