<?php
ini_set("display_errors",0);

/**
 * api
 */
class ApiClass
{
	private $conn;
	
	function __construct()
	{
		# code...
		$this->_dbConnect();
	}

	private function _dbConnect(){
		$servername = "localhost";
		$username = "root";
		$password = "infiniti";
		$dbname = "test";

		// Create connection
		$this->conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($this->conn->connect_error) {
		    die("Connection failed: " . $this->conn->connect_error);
		} 
	}

	public function getData() {
		$sql = "SELECT id, name, age FROM details";
		$result = $this->conn->query($sql);
		$data  = array();
		if ($result->num_rows > 0) {
		    // output data of each row
		    while($row = $result->fetch_assoc()) {
		        $data[] = $row;
		    }
		} else {
		    echo "0 results";
		}
		return json_encode($data);
	}

	public function addData($data) {
		$sql = "INSERT into details (name,age) VALUES('".$data['name']."','".$data['age']."')";
		return $this->conn->query($sql);
	}

	public function updateData($data) {
		$sql = "UPDATE details SET name='".$data['name']."',age='".$data['age']."' WHERE id=".$data['id'];
		return $this->conn->query($sql);
	}

	public function deleteData($data) {
		$sql = "DELETE FROM details WHERE id=".$data['id'];
		return $this->conn->query($sql);
	}
}

$apiObj = new ApiClass();

switch ($_GET['type']) {
	case 'fetch':
		$data = $apiObj->getData();
		echo $data;
		// echo file_get_contents("api.json");exit();
		break;
	case 'add':
		$apiObj->addData($_GET);
		echo "Inserted Successfuly";
		# code...
		break;
	case 'edit':
		$apiObj->updateData($_GET);
		echo "Updted Successfuly";
		# code...
		break;

	case 'delete':
		$apiObj->deleteData($_GET);
		echo "Deleted Successfuly";
		# code...
		break;
	
	default:
		$data = $apiObj->getData();
		echo $data;exit();
		break;
}
?>